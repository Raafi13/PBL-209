def substitution_cipher_encrypt(message, key):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    encrypted_message = ''
    for char in message:
        if char in alphabet:
            index = alphabet.index(char)
            encrypted_message += key[index]
        else:
            encrypted_message += char  # Non-alphabet characters remain unchanged
    return encrypted_message

def substitution_cipher_decrypt(encrypted_message, key):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    decrypted_message = ''
    for char in encrypted_message:
        if char in key:
            index = key.index(char)
            decrypted_message += alphabet[index]
        else:
            decrypted_message += char  # Non-alphabet characters remain unchanged
    return decrypted_message