document.getElementById('requestFriendForm').onsubmit = async function(event) {
    event.preventDefault();
    const username = document.getElementById('friendUsername').value.trim();

    if (!username) {
        alert('Username teman harus diisi');
        return;
    }

    try {
        const response = await fetch('/add_friend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username })
        });

        const result = await response.json();
        alert(result.status);

        if (response.ok) {
            document.getElementById('friendUsername').value = '';
            fetchFriendRequests();
            fetchFriends();
        }
    } catch (err) {
        console.error('Error mengirim permintaan pertemanan:', err);
        alert('Terjadi kesalahan saat mengirim permintaan pertemanan');
    }
};

async function respondToRequest(requestId, response) {
    try {
        const res = await fetch('/respond_friend_request', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ request_id: requestId, response })
        });

        const result = await res.json();
        alert(result.status);
        if (res.ok) {
            fetchFriendRequests();
            fetchFriends();
        }
    } catch (err) {
        console.error('Error merespons permintaan:', err);
        alert('Terjadi kesalahan saat merespons permintaan');
    }
}

async function fetchFriendRequests() {
    try {
        const response = await fetch('/friend_requests');
        if (!response.ok) throw new Error('Gagal mengambil permintaan teman');
        const requests = await response.json();
        const requestsContainer = document.getElementById('requests');
        requestsContainer.innerHTML = '';

        if (requests.length === 0) {
            requestsContainer.innerHTML = '<p>Tidak ada permintaan pertemanan.</p>';
            return;
        }

        requests.forEach(request => {
            const div = document.createElement('div');
            div.className = 'request';
            div.innerHTML = `
                <p>${request.username} mengirim permintaan pertemanan.</p>
                <button onclick="respondToRequest(${request.id}, 'accept')">Terima</button>
                <button onclick="respondToRequest(${request.id}, 'reject')">Tolak</button>
            `;
            requestsContainer.appendChild(div);
        });
    } catch (err) {
        console.error(err);
        alert('Terjadi kesalahan saat mengambil permintaan pertemanan');
    }
}

async function fetchFriends() {
    try {
        const response = await fetch('/friends');
        if (!response.ok) throw new Error('Gagal mengambil daftar teman');
        const friends = await response.json();
        const friendsList = document.getElementById('friendsList');
        friendsList.innerHTML = '';

        if (friends.length === 0) {
            friendsList.innerHTML = '<p>Anda belum memiliki teman.</p>';
            return;
        }

        friends.forEach(friend => {
            const div = document.createElement('div');
            div.innerHTML = `<p><a href="/chat_page?friend_id=${friend.id}" class="friend-link">${friend.username}</a></p>`;
            friendsList.appendChild(div);
        });
    } catch (err) {
        console.error(err);
        alert('Terjadi kesalahan saat mengambil daftar teman');
    }
}

document.getElementById('logoutButton').onclick = async function() {
    try {
        const res = await fetch('/logout', { method: 'POST' });
        const result = await res.json();
        alert(result.status);
        sessionStorage.clear();
        window.location.href = '/login_page';
    } catch (err) {
        console.error(err);
        alert('Terjadi kesalahan saat logout');
    }
};

fetchFriendRequests();
fetchFriends();
