document.getElementById('loginForm').onsubmit = async function(event) {
    event.preventDefault();
    const username = document.querySelector('input[name="username"]').value.trim();
    const password = document.querySelector('input[name="password"]').value;

    if (!username || !password) {
        alert('Username dan password tidak boleh kosong');
        return;
    }

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const result = await response.json();
        alert(result.status);

        if (response.ok) {
            // Simpan user_id ke session storage jika perlu
            sessionStorage.setItem('user_id', result.user_id);
            window.location.href = '/request_friend_page';
        }
    } catch (err) {
        console.error('Error login:', err);
        alert('Terjadi kesalahan saat login');
    }
};
