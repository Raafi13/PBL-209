document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    const messageInput = document.getElementById('messageInput');
    const messagesDiv = document.getElementById('messages');
    const friendId = document.getElementById('friendId').value;

    // Bergabung ke room chat
    socket.emit('join', { friend_id: friendId });

    // Kirim pesan saat tombol diklik
    window.sendMessage = function () {
        const message = messageInput.value.trim();
        if (!message) return;

        fetch('/send_message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                friend_id: friendId,
                message: message
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'Pesan terkirim') {
                socket.emit('message', {
                    friend_id: friendId,
                    message: message
                });
                messageInput.value = '';
            } else {
                alert(data.status);
            }
        });
    };

    // Tampilkan pesan baru dari teman
    socket.on('receive_message', data => {
        const msgElement = document.createElement('div');
        msgElement.textContent = (data.sender_id === friendId ? "Teman: " : "Anda: ") + data.message;
        messagesDiv.appendChild(msgElement);
    });

    // Ambil pesan lama saat halaman dimuat
    fetch(`/get_messages/${friendId}`)
        .then(res => res.json())
        .then(data => {
            data.forEach(msg => {
                const msgElement = document.createElement('div');
                msgElement.textContent = (msg.sender_id == friendId ? "Teman: " : "Anda: ") + msg.message;
                messagesDiv.appendChild(msgElement);
            });
        });
});
